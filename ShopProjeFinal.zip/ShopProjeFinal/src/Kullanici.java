public abstract class Kullanici implements ILoginable {
    
    protected String isim;
    protected String soyisim;
    protected String kAdi;
    protected String sifre;
    protected String telefon;

    public Kullanici(String isim, String soyisim, String kAdi, String sifre, String telefon) {
        this.isim = isim;
        this.soyisim = soyisim;
        this.kAdi = kAdi;
        this.sifre = sifre;
        this.telefon = telefon;
    }
    
    public abstract void menuyuAc();
}