import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CustomerPanel extends JFrame {
    DefaultTableModel model;
    JTable table;
    Customer aktifMusteri;

    public CustomerPanel(Customer c) {
        this.aktifMusteri = c;
        setTitle("Müşteri Paneli");
        setSize(800, 600);
        setLayout(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        
        
        JLabel lblBaslik = new JLabel("MÜŞTERİ BİLGİLERİ");
        lblBaslik.setFont(new Font("Arial", Font.BOLD, 14));
        lblBaslik.setBounds(20, 10, 200, 20);
        add(lblBaslik);

        
        add(new JLabel("Ad: " + c.isim)).setBounds(20, 40, 200, 20);
        add(new JLabel("Soyad: " + c.soyisim)).setBounds(20, 65, 200, 20);
        add(new JLabel("Tel: " + c.telefon)).setBounds(20, 90, 200, 20);
        add(new JLabel("K. Adı: " + c.kAdi)).setBounds(20, 115, 200, 20);

        
        JSeparator sep = new JSeparator();
        sep.setBounds(20, 145, 740, 10);
        add(sep);


        
        model = new DefaultTableModel(new String[]{"ID", "Kategori", "Ad", "Stok", "Fiyat"}, 0);
        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 160, 500, 350);
        add(sp);
        
        listeyiGuncelle();


        
        JLabel lAdet = new JLabel("Adet:");
        lAdet.setBounds(550, 160, 50, 25);
        add(lAdet);

        JTextField txtAdet = new JTextField();
        txtAdet.setBounds(600, 160, 100, 25);
        add(txtAdet);
        
        
        JButton btnAl = new JButton("SATIN AL");
        btnAl.setBounds(550, 200, 150, 40);
        add(btnAl);

        JButton btnGecmis = new JButton("GEÇMİŞ SİPARİŞLER");
        btnGecmis.setBounds(550, 260, 150, 40);
        add(btnGecmis);


        
        btnAl.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row == -1) { JOptionPane.showMessageDialog(null, "Lütfen bir ürün seçin!"); return; }
            try {
                int adet = Integer.parseInt(txtAdet.getText());
                if (adet <= 0) { JOptionPane.showMessageDialog(null, "En az 1 tane almalısın!"); return; }

                int id = (int) model.getValueAt(row, 0);
                for (Urun u : Veritabani.urunler) {
                    if (u.id == id) {
                        if (u.adet >= adet) {
                            
                            u.adet -= adet;
                            
                            
                            String zaman = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm"));
                            String not = "[" + zaman + "] " + u.isim + " (" + adet + " adet) - " + (u.fiyat * adet) + " TL";
                            
                            
                            aktifMusteri.siparisGecmisi.add(not);
                            Veritabani.saveProducts();
                            Veritabani.saveOrders();
                            
                            listeyiGuncelle();
                            JOptionPane.showMessageDialog(null, "Satın Alındı.");
                            txtAdet.setText("");
                        } else {
                            JOptionPane.showMessageDialog(null, "Stok Yetersiz!");
                        }
                        break;
                    }
                }
            } catch (Exception ex) { JOptionPane.showMessageDialog(null, "Lütfen sayı giriniz!"); }
        });

        btnGecmis.addActionListener(e -> new SiparisGecmisiGUI(aktifMusteri).setVisible(true));
    }

    void listeyiGuncelle() {
        model.setRowCount(0);
        for (Urun u : Veritabani.urunler) model.addRow(new Object[]{u.id, u.kategori, u.isim, u.adet, u.fiyat});
    }
}