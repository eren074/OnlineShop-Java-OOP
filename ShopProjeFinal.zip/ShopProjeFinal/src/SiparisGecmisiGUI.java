import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class SiparisGecmisiGUI extends JFrame {
    public SiparisGecmisiGUI(Customer c) {
        setTitle("Geçmiş Siparişler - " + c.isim);
        setSize(600, 400);
        setLayout(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE); 
        setLocationRelativeTo(null);

        String[] basliklar = {"Tarih", "Detay"};
        DefaultTableModel model = new DefaultTableModel(basliklar, 0);

        for (String kayit : c.siparisGecmisi) {
            String tarih = "", detay = kayit;
            
            if (kayit.startsWith("[")) {
                int index = kayit.indexOf("]");
                if (index != -1) {
                    tarih = kayit.substring(1, index);
                    detay = kayit.substring(index + 2);
                }
            }
            model.addRow(new Object[]{tarih, detay});
        }

        JTable table = new JTable(model);
        
        table.getColumnModel().getColumn(0).setPreferredWidth(120);
        table.getColumnModel().getColumn(1).setPreferredWidth(450);
        
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(10, 10, 560, 340);
        add(sp);
    }
}