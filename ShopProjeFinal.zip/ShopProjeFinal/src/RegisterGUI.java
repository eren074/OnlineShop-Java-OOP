import javax.swing.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class RegisterGUI extends JFrame {
    public RegisterGUI(boolean isAdmin) {
        setTitle("Kayıt Ol"); 
        setSize(350, 350); 
        setLayout(null); 
        setLocationRelativeTo(null);
        setResizable(false);

        
        add(new JLabel("Ad:")).setBounds(30, 20, 80, 25);
        JTextField tAd = new JTextField(); 
        tAd.setBounds(120, 20, 150, 25); 
        add(tAd);
        
        
        add(new JLabel("Soyad:")).setBounds(30, 60, 80, 25);
        JTextField tSoyad = new JTextField(); 
        tSoyad.setBounds(120, 60, 150, 25); 
        add(tSoyad);
        
        
        add(new JLabel("K.Adı:")).setBounds(30, 100, 80, 25);
        JTextField tKadi = new JTextField(); 
        tKadi.setBounds(120, 100, 150, 25); 
        add(tKadi);
        
        
        add(new JLabel("Şifre:")).setBounds(30, 140, 80, 25);
        JTextField tSifre = new JTextField(); 
        tSifre.setBounds(120, 140, 150, 25); 
        add(tSifre);
        
        
        add(new JLabel("Tel:")).setBounds(30, 180, 80, 25);
        JTextField tTel = new JTextField(); 
        tTel.setBounds(120, 180, 150, 25); 
        add(tTel);
        
        
        tTel.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                
                if (!Character.isDigit(c)) {
                    e.consume(); 
                }
            }
        });

        
        JButton btnKayit = new JButton("KAYDET"); 
        btnKayit.setBounds(100, 230, 120, 30); 
        add(btnKayit);

        btnKayit.addActionListener(e -> {
            
            if(tAd.getText().isEmpty() || tKadi.getText().isEmpty() || tTel.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Lütfen tüm alanları doldurun!"); 
                return;
            }

            if(isAdmin) {
                Veritabani.admins.add(new Admin(tAd.getText(), tSoyad.getText(), tKadi.getText(), tSifre.getText(), tTel.getText()));
                Veritabani.saveAdmins();
            } else {
                Veritabani.customers.add(new Customer(tAd.getText(), tSoyad.getText(), tKadi.getText(), tSifre.getText(), tTel.getText()));
                Veritabani.saveCustomers();
            }
            JOptionPane.showMessageDialog(null, "Kayıt Başarılı!"); 
            dispose();
        });
    }
}