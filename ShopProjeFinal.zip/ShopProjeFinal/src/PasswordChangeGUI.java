import javax.swing.*;

public class PasswordChangeGUI extends JFrame {
    public PasswordChangeGUI(boolean isAdmin) {
        setTitle("Şifre Değiştir"); setSize(300, 250); setLayout(null); setLocationRelativeTo(null);

        add(new JLabel("K.Adı:")).setBounds(20, 20, 80, 25);
        JTextField tKadi = new JTextField(); tKadi.setBounds(100, 20, 150, 25); add(tKadi);
        
        add(new JLabel("Eski Şifre:")).setBounds(20, 60, 80, 25);
        JTextField tEski = new JTextField(); tEski.setBounds(100, 60, 150, 25); add(tEski);
        
        add(new JLabel("Yeni Şifre:")).setBounds(20, 100, 80, 25);
        JTextField tYeni = new JTextField(); tYeni.setBounds(100, 100, 150, 25); add(tYeni);
        
        JButton btnDegis = new JButton("DEĞİŞTİR"); btnDegis.setBounds(80, 150, 120, 30); add(btnDegis);

        btnDegis.addActionListener(e -> {
            boolean bulundu = false;
            String k = tKadi.getText(), es = tEski.getText(), ys = tYeni.getText();
            
            if(isAdmin) {
                for(Admin a : Veritabani.admins) {
                    if(a.girisYap(k, es)) { 
                        a.sifre = ys; 
                        Veritabani.saveAdmins(); bulundu = true; break; 
                    }
                }
            } else {
                for(Customer c : Veritabani.customers) {
                    if(c.girisYap(k, es)) { 
                        c.sifre = ys; 
                        Veritabani.saveCustomers(); bulundu = true; break; 
                    }
                }
            }
            JOptionPane.showMessageDialog(null, bulundu ? "Şifre Değişti!" : "Hatalı Bilgi!");
        });
    }
}