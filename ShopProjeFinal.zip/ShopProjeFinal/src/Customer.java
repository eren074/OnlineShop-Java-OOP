import java.util.ArrayList;

public class Customer extends Kullanici {
    
    protected ArrayList<String> siparisGecmisi = new ArrayList<>();

    public Customer(String ad, String soyad, String kAdi, String sifre, String tel) {
        super(ad, soyad, kAdi, sifre, tel);
    }

    @Override
    public boolean girisYap(String kAdi, String sifre) {
        return this.kAdi.equals(kAdi) && this.sifre.equals(sifre);
    }

    @Override
    public void menuyuAc() {
        new CustomerPanel(this).setVisible(true);
    }
}