public interface ILoginable {
    boolean girisYap(String kAdi, String sifre);
}