public class Urun {
  
    protected int id;
    protected String isim;
    protected String kategori;
    protected int adet;
    protected double fiyat;

    public Urun(int id, String isim, String kategori, int adet, double fiyat) {
        this.id = id;
        this.isim = isim;
        this.kategori = kategori;
        this.adet = adet;
        this.fiyat = fiyat;
    }
}