import javax.swing.*;
import java.awt.*;

public class MainShop extends JFrame {
    public MainShop() {
        setTitle("ShopOnline - Ana Menü");
        setSize(400, 550);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);

        JLabel lblBaslik = new JLabel("ShopOnline Sistemi", SwingConstants.CENTER);
        lblBaslik.setFont(new Font("Arial", Font.BOLD, 24));
        lblBaslik.setForeground(Color.DARK_GRAY);
        lblBaslik.setBounds(50, 20, 300, 40); add(lblBaslik);

        JButton b1 = new JButton("Müşteri Kayıt Ol"); b1.setBounds(75, 80, 250, 40); b1.setBackground(Color.WHITE); add(b1);
        JButton b2 = new JButton("Yönetici Kayıt Ol"); b2.setBounds(75, 140, 250, 40); b2.setBackground(Color.WHITE); add(b2);
        JButton b3 = new JButton("Müşteri Şifre Değiştir"); b3.setBounds(75, 200, 250, 40); b3.setBackground(Color.WHITE); add(b3);
        JButton b4 = new JButton("Yönetici Şifre Değiştir"); b4.setBounds(75, 260, 250, 40); b4.setBackground(Color.WHITE); add(b4);
        JButton b5 = new JButton("Müşteri Giriş"); b5.setBounds(75, 320, 250, 40); b5.setBackground(Color.WHITE); add(b5);
        JButton b6 = new JButton("Yönetici Giriş"); b6.setBounds(75, 380, 250, 40); b6.setBackground(Color.WHITE); add(b6);

        b1.addActionListener(e -> new RegisterGUI(false).setVisible(true));
        b2.addActionListener(e -> new RegisterGUI(true).setVisible(true));
        b3.addActionListener(e -> new PasswordChangeGUI(false).setVisible(true));
        b4.addActionListener(e -> new PasswordChangeGUI(true).setVisible(true));
        b5.addActionListener(e -> new LoginGUI(false).setVisible(true));
        b6.addActionListener(e -> new LoginGUI(true).setVisible(true));
    }

    public static void main(String[] args) {
        Veritabani.baslat();
        new MainShop().setVisible(true);
    }
}