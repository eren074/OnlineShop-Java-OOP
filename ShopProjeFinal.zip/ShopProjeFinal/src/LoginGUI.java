import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginGUI extends JFrame {
    public LoginGUI(boolean isAdmin) {
        setTitle(isAdmin ? "Yönetici Giriş Paneli" : "Müşteri Giriş Paneli");
        setSize(350, 300);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);

        int lblX = 40;
        int txtX = 140;
        int gap = 40;

        JLabel l1 = new JLabel("Kullanıcı Adı:");
        l1.setFont(new Font("Arial", Font.BOLD, 13));
        l1.setBounds(lblX, 40, 100, 25);
        add(l1);

        JTextField txtKadi = new JTextField();
        txtKadi.setBounds(txtX, 40, 150, 25);
        add(txtKadi);

        JLabel l2 = new JLabel("Şifre:");
        l2.setFont(new Font("Arial", Font.BOLD, 13));
        l2.setBounds(lblX, 40 + gap, 100, 25);
        add(l2);

        JPasswordField txtPass = new JPasswordField();
        txtPass.setBounds(txtX, 40 + gap, 150, 25);
        add(txtPass);

        
        JCheckBox chkGoster = new JCheckBox("Şifreyi Göster");
        chkGoster.setFont(new Font("Arial", Font.PLAIN, 11));
        chkGoster.setBounds(txtX, 40 + gap + 30, 120, 20);
        add(chkGoster);

       
        chkGoster.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (chkGoster.isSelected()) {
                    txtPass.setEchoChar((char) 0); 
                } else {
                    txtPass.setEchoChar('●'); 
                }
            }
        });

        JButton btnGiris = new JButton("GİRİŞ YAP");
        btnGiris.setFont(new Font("Arial", Font.BOLD, 12));
        btnGiris.setBounds(100, 170, 140, 35);
        add(btnGiris);

        
        btnGiris.addActionListener(e -> {
            String kadi = txtKadi.getText();
            String sifre = new String(txtPass.getPassword());
            
            
            Kullanici girisYapan = null; 

            if (isAdmin) {
                for (Admin a : Veritabani.admins) {
                    if (a.girisYap(kadi, sifre)) {
                        girisYapan = a; 
                        break;
                    }
                }
            } else {
                for (Customer c : Veritabani.customers) {
                    if (c.girisYap(kadi, sifre)) {
                        girisYapan = c; 
                        break;
                    }
                }
            }
            
            if (girisYapan != null) {
                girisYapan.menuyuAc(); 
                dispose();
            } else {
                JOptionPane.showMessageDialog(null, "Hatalı Kullanıcı Adı veya Şifre!", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}