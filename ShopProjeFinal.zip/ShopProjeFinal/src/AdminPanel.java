import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.*;

public class AdminPanel extends JFrame {
    DefaultTableModel model;
    JTable table;

    public AdminPanel(Admin a) {
        setTitle("Yönetici Paneli");
        setSize(800, 600);
        setLayout(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        
        
        JLabel lblBaslik = new JLabel("YÖNETİCİ BİLGİLERİ");
        lblBaslik.setFont(new Font("Arial", Font.BOLD, 14));
        lblBaslik.setBounds(20, 10, 200, 20);
        add(lblBaslik);

        
        add(new JLabel("Ad: " + a.isim)).setBounds(20, 40, 200, 20);
        add(new JLabel("Soyad: " + a.soyisim)).setBounds(20, 65, 200, 20);
        add(new JLabel("Tel: " + a.telefon)).setBounds(20, 90, 200, 20);
        add(new JLabel("K. Adı: " + a.kAdi)).setBounds(20, 115, 200, 20);

        
        JSeparator sep = new JSeparator();
        sep.setBounds(20, 145, 740, 10);
        add(sep);


        
        model = new DefaultTableModel(new String[]{"ID", "Kategori", "Ad", "Stok", "Fiyat"}, 0);
        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(20, 160, 500, 350);
        add(sp);
        
        listeyiGuncelle();


       
        int startY = 160;
        int gap = 30;

        add(new JLabel("ID:")).setBounds(550, startY, 50, 20);
        JTextField tId = new JTextField(); tId.setBounds(600, startY, 150, 25); add(tId);

        add(new JLabel("Kat:")).setBounds(550, startY + gap, 50, 20);
        JTextField tKat = new JTextField(); tKat.setBounds(600, startY + gap, 150, 25); add(tKat);

        add(new JLabel("Ad:")).setBounds(550, startY + gap*2, 50, 20);
        JTextField tAd = new JTextField(); tAd.setBounds(600, startY + gap*2, 150, 25); add(tAd);

        add(new JLabel("Stok:")).setBounds(550, startY + gap*3, 50, 20);
        JTextField tStok = new JTextField(); tStok.setBounds(600, startY + gap*3, 150, 25); add(tStok);

        add(new JLabel("Fiyat:")).setBounds(550, startY + gap*4, 50, 20);
        JTextField tFiyat = new JTextField(); tFiyat.setBounds(600, startY + gap*4, 150, 25); add(tFiyat);


        
        JButton btnEkle = new JButton("EKLE");
        btnEkle.setBounds(600, startY + gap*6, 150, 30);
        add(btnEkle);

        JButton btnSil = new JButton("SİL");
        btnSil.setBounds(600, startY + gap*7 + 10, 150, 30);
        add(btnSil);

        JButton btnGuncelle = new JButton("GÜNCELLE");
        btnGuncelle.setBounds(600, startY + gap*8 + 20, 150, 30);
        add(btnGuncelle);


        
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                tId.setText(model.getValueAt(row, 0).toString());
                tKat.setText(model.getValueAt(row, 1).toString());
                tAd.setText(model.getValueAt(row, 2).toString());
                tStok.setText(model.getValueAt(row, 3).toString());
                tFiyat.setText(model.getValueAt(row, 4).toString());
            }
        });

        btnEkle.addActionListener(e -> {
            try {
                Veritabani.urunler.add(new Urun(Integer.parseInt(tId.getText()), tAd.getText(), tKat.getText(), Integer.parseInt(tStok.getText()), Double.parseDouble(tFiyat.getText())));
                Veritabani.saveProducts(); listeyiGuncelle();
                temizle(tId, tKat, tAd, tStok, tFiyat);
            } catch (Exception ex) { JOptionPane.showMessageDialog(null, "Hatalı Veri!"); }
        });

        btnSil.addActionListener(e -> {
            int row = table.getSelectedRow();
            if(row != -1) {
                int id = (int) model.getValueAt(row, 0);
                Veritabani.urunler.removeIf(u -> u.id == id);
                Veritabani.saveProducts(); listeyiGuncelle();
                temizle(tId, tKat, tAd, tStok, tFiyat);
            }
        });

        btnGuncelle.addActionListener(e -> {
             try {
                int id = Integer.parseInt(tId.getText());
                for(Urun u : Veritabani.urunler) {
                    if(u.id == id) {
                        u.isim = tAd.getText(); u.kategori = tKat.getText();
                        u.adet = Integer.parseInt(tStok.getText()); u.fiyat = Double.parseDouble(tFiyat.getText());
                        break;
                    }
                }
                Veritabani.saveProducts(); listeyiGuncelle();
                temizle(tId, tKat, tAd, tStok, tFiyat);
            } catch (Exception ex) { JOptionPane.showMessageDialog(null, "Hatalı Veri!"); }
        });
    }

    void listeyiGuncelle() {
        model.setRowCount(0);
        for (Urun u : Veritabani.urunler) model.addRow(new Object[]{u.id, u.kategori, u.isim, u.adet, u.fiyat});
    }

    void temizle(JTextField... alanlar) {
        for (JTextField t : alanlar) t.setText("");
    }
}