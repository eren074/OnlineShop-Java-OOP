import java.io.*;
import java.util.ArrayList;

public class Veritabani {
    
    public static ArrayList<Customer> customers = new ArrayList<>();
    public static ArrayList<Admin> admins = new ArrayList<>();
    public static ArrayList<Urun> urunler = new ArrayList<>();

    public static void baslat() {
        try {
            
            File fileC = new File("customers.txt");
            if (fileC.exists()) {
                BufferedReader br = new BufferedReader(new FileReader(fileC));
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    if (data.length >= 5) {
                        customers.add(new Customer(data[0], data[1], data[2], data[3], data[4]));
                    }
                }
                br.close();
            }

            
            File fileO = new File("orders.txt");
            if (fileO.exists()) {
                BufferedReader br = new BufferedReader(new FileReader(fileO));
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(";"); 
                    if (data.length >= 2) {
                        for (Customer c : customers) {
                            if (c.kAdi.equals(data[0])) { 
                                c.siparisGecmisi.add(data[1]);
                                break;
                            }
                        }
                    }
                }
                br.close();
            }

            
            File fileA = new File("admins.txt");
            if (fileA.exists()) {
                BufferedReader br = new BufferedReader(new FileReader(fileA));
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    if (data.length >= 5) {
                        admins.add(new Admin(data[0], data[1], data[2], data[3], data[4]));
                    }
                }
                br.close();
            }

            
            File fileP = new File("products.txt");
            if (fileP.exists()) {
                BufferedReader br = new BufferedReader(new FileReader(fileP));
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    urunler.add(new Urun(
                        Integer.parseInt(data[0]), data[1], data[2], 
                        Integer.parseInt(data[3]), Double.parseDouble(data[4])
                    ));
                }
                br.close();
            }

        } catch (Exception e) { e.printStackTrace(); }
    }

    
    public static void saveCustomers() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("customers.txt"))) {
            for (Customer c : customers) {
                bw.write(c.isim + "," + c.soyisim + "," + c.kAdi + "," + c.sifre + "," + c.telefon);
                bw.newLine();
            }
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static void saveOrders() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("orders.txt"))) {
            for (Customer c : customers) {
                for (String s : c.siparisGecmisi) {
                    bw.write(c.kAdi + ";" + s); 
                    bw.newLine();
                }
            }
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static void saveAdmins() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("admins.txt"))) {
            for (Admin a : admins) {
                bw.write(a.isim + "," + a.soyisim + "," + a.kAdi + "," + a.sifre + "," + a.telefon);
                bw.newLine();
            }
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static void saveProducts() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("products.txt"))) {
            for (Urun u : urunler) {
                bw.write(u.id + "," + u.isim + "," + u.kategori + "," + u.adet + "," + u.fiyat);
                bw.newLine();
            }
        } catch (IOException e) { e.printStackTrace(); }
    }
}